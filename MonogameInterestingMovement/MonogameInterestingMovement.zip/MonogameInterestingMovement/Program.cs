﻿
using var game = new MonogameInterestingMovement.Game1();
game.Run();
