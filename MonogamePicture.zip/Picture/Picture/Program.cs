﻿
using var game = new Picture.Game1();
game.Run();
