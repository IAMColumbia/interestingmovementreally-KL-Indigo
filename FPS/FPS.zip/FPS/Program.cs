﻿
using var game = new FPS.Game1();
game.Run();
