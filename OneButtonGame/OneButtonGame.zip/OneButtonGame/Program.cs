﻿
using var game = new OneButtonGame.Game1();
game.Run();
